import classes from './Cart.module.css'
import Modal from '../UI/Modal'
import cartContext from '../../store(context)/cart-context'
import { useContext, useState } from 'react'
import CartItem from './CartItem'
import Checkout from './Checkout'
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


const Cart = (props) => {

    const [isCheckout, setIsCheckOut] = useState(false)
    const Cart_Context = useContext(cartContext)

    const addItemHandler = (item) => {
        Cart_Context.addItem({ ...item, amount: 1 })
    }

    const removeItemHandler = (itemId) => {
        Cart_Context.removeItem(itemId)
    }

    const checkOutHandler = () => {
        setIsCheckOut(true)
    }

    const orderSubmitHandler = (userData) => {
        fetch("http://127.0.0.1:5000/orderData", {
            method: "POST",
            body: JSON.stringify({
                user: userData,
                orderedItems: Cart_Context.items
            })
        }).then((response) => {
            return response.json();            
        }).then((data) => {
            if (data.status === 200) {
                toast.success(data.message); // Show success toaster (Toaster is in app.js)
              } else {
                toast.error(data.message); // Show error toaster
              }
            props.onClose()
        })
    }

    const cartItems = <ul className={classes['cart-items']}>
        {Cart_Context.items.map((item) => {
            return <CartItem key={item.id}
                name={item.name}
                price={item.price}
                amount={item.amount}
                onRemove={removeItemHandler.bind(null, item.id)}
                onAdd={addItemHandler.bind(null, item)}
            />
        })}
    </ul>

    const totalAmount = `$${Cart_Context.totalAmount.toFixed(2)}`
    const hasItems = Cart_Context.items.length > 0

    const modalActions = <div className={classes.actions}>
        <button className={classes['button--alt']} onClick={props.onClose} >Close</button>
        {hasItems && <button className={classes.button} onClick={checkOutHandler}>Order</button>}
    </div>

    return (
        <Modal onClose={props.onClose}>
            {cartItems}
            <div className={classes.total}>
                <span>Total Amount</span>
                <span>{totalAmount}</span>
            </div>
            {!isCheckout && modalActions}
            {isCheckout && <Checkout onCancel={props.onClose} onSubmit={orderSubmitHandler} />}
        </Modal>
    )
}

export default Cart