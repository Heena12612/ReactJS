import classes from './Header.module.css'
import mealsImage from '../../assets/meals.jpg'
import HeaderCartButton from './HeaderCartButton'


const Header = (props) => {
    return <>
        <header className={classes.header}>
            <h1>React Meals</h1>
            <HeaderCartButton onShowCart={props.onShowCart}/>
        </header>
        <div className={classes['main-image']}>    
            {/*here classes[] this format is used because of - in main-image */}
            <img src={mealsImage} alt="Delicious food on table!"/>
        </div>
    </>
}

export default Header 