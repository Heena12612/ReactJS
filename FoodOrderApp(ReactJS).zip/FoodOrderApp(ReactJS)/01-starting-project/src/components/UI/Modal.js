import React from 'react';
import classes from './Modal.module.css';
import ReactDOM from 'react-dom';

const Backdrop = (props) => {
  return <div className={classes.backdrop} onClick={props.onClose}></div>;
};

const ModalOverlay = (props) => {
  return (
    <div className={classes.modal}>
      <div className={classes.content}>{props.children}</div>
    </div>
  );
};

const whereToPlacePortalElement = document.getElementById('overlays');

const Modal = (props) => {
  return (
    <>
      {ReactDOM.createPortal(
        <Backdrop onClose={props.onClose} />,
        whereToPlacePortalElement
      )}
      {ReactDOM.createPortal(
        <ModalOverlay>
          <div className={classes.scrollableContent}>{props.children}</div>
        </ModalOverlay>,
        whereToPlacePortalElement
      )}
    </>
  );
};

export default Modal;
