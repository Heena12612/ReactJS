import Header from "./components/Layout/Header";
import Meals from './components/Meals/Meals.js'
import Cart from "./components/Cart/Cart.js"
import { useState, useEffect } from 'react'
import CartProvider from "./store(context)/CartProvider";
import classes from "./components/Meals/AvailableMeals.module.css"
import { ToastContainer } from 'react-toastify';



function App() {

  const [fetchData, setFetchData] = useState([])
  const [isDataLoading, setDataLoading] = useState(true)
  const [httpError,setHttpError] = useState()

  useEffect(() => {
    fetch("http://127.0.0.1:5000/", {
      method: "GET",
      headers: { "Content-Type": "application/json" },
    })
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        console.log(data)
        setFetchData(data);
        setDataLoading(false)

      })
      .catch((error) => {
        setHttpError(error.message)
        setDataLoading(false)
      });
  }, [])

  console.log(fetchData, " from app")

  const [isCartShown, setCartShow] = useState(false);

  const showCartHandler = () => {
    setCartShow(true);
  }
  const hideCartHandler = () => {
    setCartShow(false)
  }


  return (
    <CartProvider>
       <ToastContainer /> {/*toast message is set in cart.js */}
      {isCartShown && <Cart onClose={hideCartHandler} />}
      <Header onShowCart={showCartHandler} /> 
      <main>
        {isDataLoading ? 
          <p className={classes.MealsLoading}>Loading.........</p>
         :
         httpError ? <p className={classes.MealsLoading}>{httpError}</p> :
         <Meals data={fetchData} />}
      </main>
    </CartProvider>
  );
}

export default App;
