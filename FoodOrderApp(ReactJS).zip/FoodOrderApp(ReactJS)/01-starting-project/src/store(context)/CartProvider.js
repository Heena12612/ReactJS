import { useReducer } from "react"
import cartContext from "./cart-context"
import { act } from "react-dom/test-utils"

const defaultCartState = {
    items: [],
    totalAmount: 0
}

const cartReducer = (latestState,action) => {
    console.log(`defaultstate amount: ${latestState.totalAmount}`)
    if(action.type === 'ADD_TO_CART'){

        const updatedTotalAmount = latestState.totalAmount + action.item.price * action.item.amount

        const existingItemIndex = latestState.items.findIndex((item) =>  item.id === action.item.id )
        const existingItem = latestState.items[existingItemIndex]

        let updatedCartItemsWithoutDuplicates;

        if(existingItem){
            const updatedItem = {
                ...existingItem,
                amount: existingItem.amount + action.item.amount
            }
            updatedCartItemsWithoutDuplicates = [...latestState.items]
            updatedCartItemsWithoutDuplicates[existingItemIndex] = updatedItem  
            
            console.log("already added: ",updatedCartItemsWithoutDuplicates)

        }
        else{
            updatedCartItemsWithoutDuplicates = latestState.items.concat(action.item)
            console.log("newly added: ",updatedCartItemsWithoutDuplicates)
        }
       
        return {
            items: updatedCartItemsWithoutDuplicates,
            totalAmount: updatedTotalAmount
        }
    }
    if(action.type === 'REMOVE_FROM_CART'){

        const existingItemIndex = latestState.items.findIndex((item) => item.id === action.itemId )
        const existingItem = latestState.items[existingItemIndex]

        let updatedItems;
        if(existingItem.amount === 1){
            updatedItems = latestState.items.filter((item) => item.id !== action.itemId)
        }
        else{
            const updatedItem = {...existingItem,amount:existingItem.amount-1}
            updatedItems = [...latestState.items]
            updatedItems[existingItemIndex] = updatedItem
        }
        const updatedTotalAmount = latestState.totalAmount - existingItem.price
        
        return {
            items: updatedItems,
            totalAmount: updatedTotalAmount
        }
    }
    return defaultCartState
}


const CartProvider = (props) => {

    
   const [cartState,dispatchCartAction] =  useReducer(cartReducer,defaultCartState)

    const addItemToCartHandler = (item) => {
        dispatchCartAction({type: 'ADD_TO_CART',item: item})
    }

    const removeItemFronCartHandler = (itemId) => {
        dispatchCartAction({type: 'REMOVE_FROM_CART',itemId: itemId})
    }

    const cartContextHelper = {
        items: cartState.items,
        totalAmount: cartState.totalAmount,
        addItem: addItemToCartHandler,
        removeItem: removeItemFronCartHandler
    }

    return (
        <cartContext.Provider value={cartContextHelper}>
            {props.children}
        </cartContext.Provider>
    )
}
export default CartProvider